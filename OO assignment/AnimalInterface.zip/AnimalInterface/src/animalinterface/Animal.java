/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animalinterface;

/**
 *
 * @author Stanlee
 */
public class Animal implements AnimalInterface {

    private String type;
    private String movement;
    private int numLegs;

   

    public String animalType(String type) {
        this.type = type;
        return this.type;
    }
    
    public String animalMovement(String movement) {
        this.movement = movement;
        return this.movement;
    }

    public int numberOfLegs(int numLegs) {
        this.numLegs = numLegs;
        return this.numLegs;
    }
}
