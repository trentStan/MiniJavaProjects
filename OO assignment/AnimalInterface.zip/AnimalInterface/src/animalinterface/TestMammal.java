/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animalinterface;

/**
 *
 * @author Stanlee
 */
public class TestMammal {
    Mammal dog = new Mammal(6);

    public TestMammal() {
    
        System.out.println("Animal type: " + dog.animalType("Mammal"));
        System.out.println("Animal movement: " + dog.animalMovement("Classical gallop"));
        System.out.println("Number of legs: " + dog.numberOfLegs(4));
        System.out.println("Number of nipples: " + dog.getNumNipples());
    }
    
    
}
