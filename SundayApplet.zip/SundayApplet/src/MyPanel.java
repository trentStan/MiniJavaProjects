
import java.awt.*;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author user-pc
 */
public class MyPanel extends JPanel {

    public void paintComponent(Graphics g) {
        
        
        g.setColor(Color.BLACK);
        g.drawRect(50, 50, 200, 66);
        g.drawString("User", 135, 90);

        g.drawRect(600, 50, 200, 66);
        g.drawString("Developer Administrator", 640, 90);

        g.drawOval(350, 20, 150, 150);
        g.drawString("Administrator", 390, 95);
        
        g.drawLine(250, 70, 360, 60);
        g.drawLine(250, 110, 360, 130);
        
        g.drawLine(490, 60, 600, 65);
        g.drawLine(490, 130, 600, 100);
        
        g.drawString("Provides information on missing persons", 150, 40);
        g.drawString("Provides information and ongoing", 190, 160);
        g.drawString("Receives requests from Administrator", 490, 40);
        g.drawString("Provides privileges and creates new users", 500, 150);
    }
}
