/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JApplet;

/**
 *
 * @author user-pc
 */
public class MyApplet extends JApplet {

    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    public void init() {
        this.setSize(900, 200);
        this.add(new MyPanel());
    }

    // TODO overwrite start(), stop() and destroy() methods
}
